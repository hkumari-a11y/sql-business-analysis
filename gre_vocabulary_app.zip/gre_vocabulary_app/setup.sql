CREATE DATABASE IF NOT EXISTS gre_vocabulary
CHARACTER SET utf8mb4
COLLATE utf8mb4_unicode_ci;

USE gre_vocabulary;

CREATE TABLE IF NOT EXISTS vocabulary (
    id INT AUTO_INCREMENT PRIMARY KEY,
    word VARCHAR(100) NOT NULL UNIQUE,
    definition VARCHAR(500) NOT NULL
);

INSERT INTO vocabulary (word, definition) VALUES
('Abate', 'to put an end to; nullify'),
('Abjure', 'to renounce upon oath; to reject solemnly'),
('Abrogate', 'to abolish by authoritative action; annul'),
('Abstruse', 'difficult to comprehend; obscure'),
('Acarpous', 'effete; no longer fertile; worn out')
ON DUPLICATE KEY UPDATE definition = VALUES(definition);
