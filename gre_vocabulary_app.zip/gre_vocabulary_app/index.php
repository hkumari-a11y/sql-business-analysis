<?php
require_once 'config.php';

$searchedWord = '';
$definition = '';
$messageClass = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $searchedWord = trim($_POST['word'] ?? '');

    if ($searchedWord === '') {
        $definition = 'Please enter a word.';
        $messageClass = 'error';
    } else {
        try {
            $stmt = $pdo->prepare('SELECT definition FROM vocabulary WHERE LOWER(word) = LOWER(:word) LIMIT 1');
            $stmt->execute(['word' => $searchedWord]);
            $result = $stmt->fetch();

            if ($result) {
                $definition = $result['definition'];
                $messageClass = 'success';
            } else {
                $definition = 'undefined';
                $messageClass = 'error';
            }
        } catch (PDOException $e) {
            $definition = 'Database error. Please verify the settings in config.php.';
            $messageClass = 'error';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>GRE Vocabulary Finder</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <main class="card">
        <h1>GRE Vocabulary</h1>
        <p class="subtitle">Search for the definition of a GRE word.</p>

        <form method="post" action="" class="search-form">
            <label for="word">Word</label>
            <div class="input-row">
                <input
                    type="text"
                    id="word"
                    name="word"
                    value="<?= htmlspecialchars($searchedWord, ENT_QUOTES, 'UTF-8') ?>"
                    placeholder="Enter a word"
                    required
                    autofocus
                >
                <button type="submit">Search</button>
            </div>
        </form>

        <?php if ($definition !== ''): ?>
            <section class="result <?= $messageClass ?>" aria-live="polite">
                <strong>Definition:</strong>
                <span><?= htmlspecialchars($definition, ENT_QUOTES, 'UTF-8') ?></span>
            </section>
        <?php endif; ?>

        <section class="available-words">
            <h2>Words in the database</h2>
            <p>Abate, Abjure, Abrogate, Abstruse, Acarpous</p>
        </section>
    </main>
</body>
</html>
