GRE VOCABULARY WEB APPLICATION

Files included:
- index.php: Main search page and PHP logic
- config.php: MySQL connection settings
- setup.sql: Database, table, and required vocabulary entries
- style.css: Page design

HOW TO RUN LOCALLY WITH XAMPP/MAMP
1. Start Apache and MySQL.
2. Open phpMyAdmin.
3. Import setup.sql.
4. Place the gre_vocabulary_app folder in htdocs (XAMPP) or the MAMP document root.
5. Check config.php and update the MySQL username/password if needed.
6. Open:
   http://localhost/gre_vocabulary_app/

HOW TO PUBLISH
1. Create a MySQL database on your hosting account.
2. Import setup.sql through the hosting database manager/phpMyAdmin.
3. Upload index.php, config.php, and style.css to public_html or a subfolder.
4. Enter the hosting database name, username, and password in config.php.
5. Open the public URL and test all five words plus an unknown word.

SUBMISSION
Submit:
1. The valid public URL of the working website.
2. The PHP source-code files, preferably as this ZIP file.

Expected behavior:
- A matching word shows its definition.
- A word not in the database displays "undefined".
- Search is case-insensitive.
